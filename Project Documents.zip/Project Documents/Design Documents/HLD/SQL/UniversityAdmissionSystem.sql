Programs Offered:
SQL> desc programs_offered
 Name                                      Null?    Type
 ----------------------------------------- -------- -------------------

 PROGRAM_NAME                              NOT NULL VARCHAR2(5)
 DESCRIPTION                                        VARCHAR2(20)
 APPLICANT_ELIGIBILITY                              VARCHAR2(40)
 DURATION                                           NUMBER(3)
 DEGREE_CERTIFICATE_OFFERED                         VARCHAR2(10)

Application:
SQL> DESC APPLICATION;
 Name                                      Null?    Type
 ----------------------------------------- -------- -------------------

 APPLICATION_ID                            NOT NULL NUMBER(6)
 FULL_NAME                                          VARCHAR2(20)
 DATE_OF_BIRTH                                      DATE
 HIGHEST_QUALIFICATION                              VARCHAR2(10)
 MARKS_OBTAINED                                     NUMBER(3)
 GOALS                                              VARCHAR2(20)
 EMAIL_ID                                           VARCHAR2(20)
 STATUS                                             VARCHAR2(10)
 DATE_OF_INTERVIEW                                  DATE

Users:
SQL> DESC USERS;
 Name                                      Null?    Type
 ----------------------------------------- -------- -------------------

 LOGIN_ID                                           VARCHAR2(5)
 PASSWORD                                           VARCHAR2(10)
 ROLE                                      NOT NULL VARCHAR2(5)

SQL>

-------------------------------------------------------------------------------
Logins:

INSERT INTO USERS VALUES('mac01','mac001','mac');

INSERT INTO USERS VALUES('adm02','adm002','admin');