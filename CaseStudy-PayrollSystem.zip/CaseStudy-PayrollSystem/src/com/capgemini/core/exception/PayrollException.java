package com.capgemini.core.exception;

public class PayrollException extends Exception
{

}