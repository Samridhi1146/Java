package com.capgemini.core.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.capgemini.core.beans.EmployeeBean;
import com.capgemini.core.service.IPayrollService;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class PayrollController 
{
	@Autowired
	IPayrollService payrollservice;
	/*
	//Add employee:
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addData(@ModelAttribute("my")EmployeeBean employee,Map<String,Object>model)
	{
		List<String> myList=new ArrayList<String>();
		myList.add("JAVA");
		myList.add("Testing");
		myList.add(".NET");
			
		model.put("traineetype",myList);
		return "addTrainee";
	}
	
	@RequestMapping(value="putdata",method=RequestMethod.POST)
	public ModelAndView dataAdd(@ModelAttribute("my") EmployeeBean employee)
	{
		int employeeId=payrollservice.insertEmployee(employee);
		return new ModelAndView("EmployeeAdded", "employee", employeeId);
	}
	
	//Show Employee:
	@RequestMapping(value="showall",method=RequestMethod.GET)
	public ModelAndView dataShow()
	{ 
		List<EmployeeBean> allData=payrollservice.getAllEmployees();
		return new  ModelAndView("show Employee","employee",allData);
	}
	*/
}