package com.capgemini.core.dao;

import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.capgemini.core.beans.EmployeeBean;

@Repository("payrolldao")
public class PayrollDaoImpl implements IPayrollDao
{
	@PersistenceContext
	EntityManager entityManager;
	
	//Insertion employee:
	@Override
	public int insertEmployee(EmployeeBean employee) throws SQLException 
	{
		entityManager.persist(employee);
		entityManager.flush();
		return employee.getEmployeeId();
	}

	//Delete employee:
	@Override
	public void deleteEmployee(int employeeId) throws SQLException
	{
		Query queryTwo=entityManager.createQuery("DELETE FROM EmployeeBean WHERE employeeId=:employee_Id");
		queryTwo.setParameter("employee_id", employeeId);
		queryTwo.executeUpdate();
	}

	//Update employee:
	@Override
	public boolean updateEmployee(EmployeeBean employee) throws SQLException 
	{
		Query queryThree = entityManager.createQuery("Update EmployeeBean SET firstName=:first_Name,lastName=:last_Name,mobileNo:=mobile_No,pancard:=pancard,emailId:=email_Id,yearlyInvestmentUnder80C:=yearlyInvestmentUnder80C WHERE employeeId=:employee_Id");
		queryThree.setParameter("first_Name", employee.getFirstName());
		queryThree.setParameter("last_Name", employee.getLastName());
		queryThree.setParameter("mobile_No", employee.getMobileNo());
		queryThree.setParameter("pancard", employee.getPancard());
		queryThree.setParameter("email_Id", employee.getEmailId());
		queryThree.setParameter("yearlyInvestmentUnder80C", employee.getYearlyInvestmentUnder80C());
		queryThree.executeUpdate();
		return true;
	}
	
	//Search employee:
	@Override
	public EmployeeBean getEmployee(int employeeId) throws SQLException 
	{
		Query queryFour=entityManager.createQuery("FROM EmployeeBean WHERE employeeId=:employee_Id");
		queryFour.setParameter("employee_Id",employeeId);
		EmployeeBean mySearch=(EmployeeBean) queryFour.getResultList();
		return mySearch;
	}

	//Show all employees:
	@Override
	public List<EmployeeBean> getAllEmployees() throws SQLException 
	{
		Query queryOne=entityManager.createQuery("FROM EmployeeBean"); 
		List<EmployeeBean> dataList=queryOne.getResultList();
		return dataList;
	}
}