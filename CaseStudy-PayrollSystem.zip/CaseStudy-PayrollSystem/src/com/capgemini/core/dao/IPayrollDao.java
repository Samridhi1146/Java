package com.capgemini.core.dao;

import java.sql.SQLException;
import java.util.List;

import com.capgemini.core.beans.EmployeeBean;

public interface IPayrollDao 
{
	int insertEmployee(EmployeeBean employee)throws SQLException;
	
	boolean updateEmployee(EmployeeBean employee)throws SQLException;
	
	void deleteEmployee(int employeeId)throws SQLException;
	
	EmployeeBean getEmployee(int employeeId)throws SQLException;
	
	List<EmployeeBean>getAllEmployees()throws SQLException;
}