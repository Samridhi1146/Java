package com.capgemini.core.beans;

import javax.persistence.Embeddable;

@Embeddable
public class BankDetailsBean 
{
	private int accountNo;
	private String bankName;
	private String bankIFSCode;
	
	//Getters and setters:
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getBankIFSCode() {
		return bankIFSCode;
	}
	public void setBankIFSCode(String bankIFSCode) {
		this.bankIFSCode = bankIFSCode;
	}
	
	//To string:
	@Override
	public String toString() {
		return "BankDetailsBean [accountNo=" + accountNo + ", bankName="
				+ bankName + ", bankIFSCode=" + bankIFSCode + "]";
	}
}