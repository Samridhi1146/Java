package com.capgemini.core.beans;

import javax.persistence.Embeddable;

@Embeddable
public class SalaryBean 
{
	private int basicSalary;
	private int hra;
	private int ta;
	private int da;
	private int companyPf;
	private int employeePf; 
	private int grossSalary;
	private int monthlyTax;
	private int netSalary;
	
	//Getters and setters:
	public int getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(int basicSalary) {
		this.basicSalary = basicSalary;
	}
	public int getHra() {
		return hra;
	}
	public void setHra(int hra) {
		this.hra = hra;
	}
	public int getTa() {
		return ta;
	}
	public void setTa(int ta) {
		this.ta = ta;
	}
	public int getDa() {
		return da;
	}
	public void setDa(int da) {
		this.da = da;
	}
	public int getCompanyPf() {
		return companyPf;
	}
	public void setCompanyPf(int companyPf) {
		this.companyPf = companyPf;
	}
	public int getEmployeePf() {
		return employeePf;
	}
	public void setEmployeePf(int employeePf) {
		this.employeePf = employeePf;
	}
	public int getGrossSalary() {
		return grossSalary;
	}
	public void setGrossSalary(int grossSalary) {
		this.grossSalary = grossSalary;
	}
	public int getMonthlyTax() {
		return monthlyTax;
	}
	public void setMonthlyTax(int monthlyTax) {
		this.monthlyTax = monthlyTax;
	}
	public int getNetSalary() {
		return netSalary;
	}
	public void setNetSalary(int netSalary) {
		this.netSalary = netSalary;
	}
	
	//To string:
	@Override
	public String toString() {
		return "SalaryBean [basicSalary=" + basicSalary + ", hra=" + hra
				+ ", ta=" + ta + ", da=" + da + ", companyPf=" + companyPf
				+ ", employeePf=" + employeePf + ", grossSalary=" + grossSalary
				+ ", monthlyTax=" + monthlyTax + ", netSalary=" + netSalary
				+ "]";
	}
}