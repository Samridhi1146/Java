package com.capgemini.core.service;

import java.sql.SQLException;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.capgemini.core.beans.EmployeeBean;
import com.capgemini.core.dao.IPayrollDao;

@Service("payrollservice")
@Transactional
public class PayrollServiceImpl implements IPayrollService
{
	IPayrollDao payrolldao;

	@Override
	public int insertEmployee(EmployeeBean employeebean) throws SQLException 
	{
		return payrolldao.insertEmployee(employeebean);
	}

	@Override
	public boolean updateEmployee(EmployeeBean employeebean) throws SQLException 
	{
		return false;
	}

	@Override
	public void deleteEmployee(int employeeId) throws SQLException 
	{
		payrolldao.deleteEmployee(employeeId);
	}

	@Override
	public EmployeeBean getEmployee(int employeeId) throws SQLException 
	{
		return null;
	}

	@Override
	public List<EmployeeBean> getAllEmployees() throws SQLException 
	{
		return payrolldao.getAllEmployees();
	}
}