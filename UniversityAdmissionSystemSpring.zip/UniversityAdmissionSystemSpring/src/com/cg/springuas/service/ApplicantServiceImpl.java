package com.cg.springuas.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.jboss.resteasy.spi.ApplicationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springuas.bean.Application;
import com.cg.springuas.bean.ProgramsOffered;
import com.cg.springuas.dao.IApplicantDAO;
import com.cg.springuas.exception.AppicationException;

@Service("applicationService")
@Transactional
public class ApplicantServiceImpl implements IApplicantService
{
	@Autowired
	IApplicantDAO applicationDao;
	
	@Override
	public int addApplicant(Application app) throws ApplicationException {
		// TODO Auto-generated method stub
		return applicationDao.addApplicant(app);
	}


	@Override
	public List<Application> viewApplication(int applicationid) throws ApplicationException {
		// TODO Auto-generated method stub
		return applicationDao.viewApplication(applicationid);
	}

	@Override
	public List<Application> getAllApplications()
			throws ApplicationException {
		// TODO Auto-generated method stub
		return applicationDao.getAllApplications();
	}

	@Override
	public List<ProgramsOffered> getAllPrograms()
			throws ApplicationException {
		// TODO Auto-generated method stub
		return applicationDao.getAllPrograms();
	}

	@Override
	public void update(Application app) throws ApplicationException {
		// TODO Auto-generated method stub
		applicationDao.update(app);	
	}

	@Override
	public void update(ProgramsOffered prog) throws ApplicationException {
		// TODO Auto-generated method stub
		applicationDao.update(prog);
	}

	@Override
	public ProgramsOffered viewProgram(String programName) {
		// TODO Auto-generated method stub
		return applicationDao.viewProgram(programName);
	}

	@Override
	public void deleteProgramsOffered(String progName) {
		// TODO Auto-generated method stub
		applicationDao.deleteProgramsOffered(progName);
	}

	@Override
	public String addProgram(ProgramsOffered prog) throws ApplicationException {
		// TODO Auto-generated method stub
		applicationDao.addProgram(prog);
		return applicationDao.addProgram(prog);
	}


	@Override
	public String getRole(String loginid, String pass)
	{
		
		return applicationDao.getRole(loginid, pass);
	}


	@Override
	public Application findApplication(int id) {
		// TODO Auto-generated method stub
		return applicationDao.findApplication(id);
	}


	@Override
	public ProgramsOffered findProgram(String progName) {
		// TODO Auto-generated method stub
		return applicationDao.findProgram(progName);
	}

}
