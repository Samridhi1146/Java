package com.cg.springuas.controller;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springuas.bean.Application;
import com.cg.springuas.bean.ProgramsOffered;
import com.cg.springuas.service.IApplicantService;

@Controller
public class ApplicationController 
{
	@Autowired
	IApplicantService applicationService;
	
	
	@RequestMapping(value="add",method=RequestMethod.GET)
	public ModelAndView addApp(@ModelAttribute("my") Application app)
	{
		List<ProgramsOffered> progList = applicationService.getAllPrograms();
		return new ModelAndView("programsOffered","plist",progList );
		
	}
	
	@RequestMapping(value="apply",method=RequestMethod.GET)
	public String addApplicant(@ModelAttribute("my") Application app)
	{
		return "addApplication";
	}
	
	
	@RequestMapping(value="putdata",method=RequestMethod.POST)
	public ModelAndView addApplication(@Valid@ModelAttribute("my") Application app,BindingResult error)
	{
		
		if (error.hasErrors()) 
		{
	
			return new ModelAndView("addApplication");
			
		}
		else
		{
			int appId=applicationService.addApplicant(app);
			return new ModelAndView("success", "app", appId);
		}
		
	}
	
	@RequestMapping(value="view",method=RequestMethod.GET)
	public String viewApp(@ModelAttribute("data") Application app1)
	{
		return "viewApp";
	}
	
	@RequestMapping(value="searchApplication",method=RequestMethod.POST)
	public ModelAndView searchMobile(@ModelAttribute ("data") Application aData)
	{
		int appId = aData.getApplicationId();
		List<Application> searchedApplication = applicationService.viewApplication(appId);
		System.out.println( searchedApplication);
		return new ModelAndView("list","aList",searchedApplication);
	}
	
	@RequestMapping(value="login",method=RequestMethod.GET)
	public String myLog(@ModelAttribute("data") Application app1)
	{
		return "login";
	}
	
	@RequestMapping(value="Login.do",method=RequestMethod.POST)
	public String myLogin(@RequestParam("loginid") String loginid , @RequestParam("pass") String pass)
	{
		String retPage = null;
		String role = applicationService.getRole( loginid, pass);
		if (role.equals("") || role.equals(null))
		{
			
			retPage = "error";
					
		}
		
		else if(role.equals("mac"))
		{
			retPage = "Mac";
		}
		
		else if(role.equals("admin"))
		{
			retPage = "Admin";
		}
		return retPage;
	}
	@RequestMapping(value="showall",method=RequestMethod.GET)
	public ModelAndView showAllApplication()
	{	
		List<Application> dataList = applicationService.getAllApplications();
		return new ModelAndView("appList","alist",dataList);
	}
	
	@RequestMapping(value="showallProg",method=RequestMethod.GET)
	public ModelAndView showAllPrograms()
	{	
		List<ProgramsOffered> progList = applicationService.getAllPrograms();
		return new ModelAndView("progList","plist",progList );
	}
	
	@RequestMapping(value="update",method=RequestMethod.GET)
	public String update(@RequestParam("id") int id,Map<String, Object> model, @ModelAttribute ("my") Application app)
	{	
		app = applicationService.findApplication(id);
		model.put("my", app);
		return "updateApplication";
	}
	
	@RequestMapping(value="putData",method=RequestMethod.POST)
	public String changeData(@ModelAttribute ("my") Application app)
	{	
		applicationService.update(app);
		return "redirect:/showall";
	}
	
	@RequestMapping(value="updated",method=RequestMethod.GET)
	public String updated(@RequestParam("programname") String programname,Map<String, Object> model, @ModelAttribute ("my") ProgramsOffered prog)
	{	
		prog = applicationService.findProgram(programname);
		model.put("my", prog);
		return "updateProgram";
	}
	
	@RequestMapping(value="insertData",method=RequestMethod.POST)
	public String updateProg(@ModelAttribute ("my") ProgramsOffered prog)
	{	
		applicationService.update(prog);
		return "redirect:/showallProg";
	}
	
	@RequestMapping(value="remove", method=RequestMethod.GET)
	public String delete(@RequestParam ("programname") String programname)
	{
		applicationService.deleteProgramsOffered(programname);;
		return "redirect:/showallProg";
	}
	
	@RequestMapping(value="addProg",method=RequestMethod.GET)
	public String addProg(@ModelAttribute("my") ProgramsOffered prog)
	{
		return "addProgram";
	}
	
	@RequestMapping(value="addData",method=RequestMethod.POST)
	public ModelAndView addProgram(@ModelAttribute("my") ProgramsOffered prog)
	{
		String progName = applicationService.addProgram(prog);
		return new ModelAndView("progSuccess", "prog", progName);
	}
	
	
}
