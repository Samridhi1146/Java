package com.cg.springuas.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name="USERS")
@Table(name="USERS")
public class Users 
{
	@Column(name="login_id")
	private String loginid;
	
	@Column(name="password")
	private String password;
	
	@Id
	@Column(name="role")
	private String role;
	
	public String getLoginid() 
	{
		return loginid;
	}
	public void setLoginid(String loginid) {
		this.loginid = loginid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "Users [loginid=" + loginid + ", password=" + password
				+ ", role=" + role + "]";
	}
}
