package com.cg.springuas.bean;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;


@Entity(name="APPLICATION")
@Table(name="APPLICATION")
public class Application 
{
	@Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE,generator="appid")
    @SequenceGenerator(name="appid",sequenceName="SEQ_APPID")
    @Column(name="application_id")
	private int applicationId;
	
	@Column(name="full_name")
	@NotEmpty(message="Applicant name is required")
	@Size(min=2,max=20,message="Name should be 2 to 20 characters long")
	@Pattern(regexp="^[A-Z][a-z]+$",message="First Character should be capital")
	private String fullName;
	
	@Column(name="date_of_birth")
	@NotNull(message="Birth Date is required")
	private Date dob;
	
	@Column(name="highest_qualification")
	@NotNull(message="Highest Qualification is required")
	@Size(max=10,message="Max Size is 10")
	private String highestQual;
	
	@Column(name="marks_obtained")
	@NotNull(message="Marks are required")
	private double marks;
	
	@Column(name="goals")
	@NotNull(message="Marks is required")
	@Pattern(regexp="^[A-Z][a-z]+$",message="First Character should be Capital")
	@Size(max=20,message="max size is 20")
	private String goals;
	
	@Column(name="email_id")
	@NotNull(message="Email Id is required")
	@Email(message="Follow the Email Pattern")
	@Size(max=20,message="max size is 20")
	private String emailId;
	
	@Column(name="status")
	@Pattern(regexp="^[A-Z][a-z]+$",message="First Character should be Capital")
	private String status;
	
	@Column(name="date_of_interview")
	private Date doi;
	
	public int getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getHighestQual() {
		return highestQual;
	}
	public void setHighestQual(String highestQual) {
		this.highestQual = highestQual;
	}
	public double getMarks() {
		return marks;
	}
	public void setMarks(double marks) {
		this.marks = marks;
	}
	public String getGoals() {
		return goals;
	}
	public void setGoals(String goals) {
		this.goals = goals;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getDoi() {
		return doi;
	}
	public void setDoi(Date doi) {
		this.doi = doi;
	}
	@Override
	public String toString() {
		return "Application [applicationId=" + applicationId + ", fullName="
				+ fullName + ", dob=" + dob + ", highestQual=" + highestQual
				+ ", marks=" + marks + ", goals=" + goals + ", emailId="
				+ emailId + ", status=" + status + ", doi=" + doi + "]";
	}
}
