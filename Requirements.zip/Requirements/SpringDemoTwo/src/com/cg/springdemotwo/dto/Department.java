package com.cg.springdemotwo.dto;

import org.springframework.stereotype.Component;

@Component("dept")
public class Department
{

	public void showDepartment(){
		System.out.println("In Java Dept.");
	}
}