var countriesModule=angular.module("countriesModule",[]);

countriesModule.run(function($rootScope)
{
	//alert("In countriesModule.")
	$rootScope.title='Country Master Console.';
}
);

countriesModule.controller("countriesControl",
		function($scope,$http)
		{
		_refreshPageData()
		//The list here is supposed to come from the server.
			
		function _refreshPageData()
		{
		$http				
		(													//Inside this ( and this ),is the object of JSON. 
		{													//This same method is passed onto HTTP.
			method: 'GET',
			url: 'http://localhost:8083/SpringWithAngular/rest/countries.json'		//.json depicts that json type of data is inserted.
		}
		).success(function(data)
				{
					$scope.countries=data; 							// Response data .
				}
			);
		}
	}
);