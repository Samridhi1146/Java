var billModule=angular.module("billModule",[]);				//[] contains dependency injection.

billModule.run(function($rootScope)							//As good as calling a constructor.
	{
		alert("In run method.");
		$rootScope.title="Bill Calculations.";
	}
);

//Controller 1 directly created:
billModule.controller("productController",function($scope)
	{
	$scope.product=
		{
			'cost':0,
			'qty':1,
			'discount':0
		};
	
	$scope.calcTotalBill=function()
		{
			return  $scope.product.cost *  $scope.product.qty;
		};
		
	$scope.calcDiscountBill=function()
		{
			return $scope.calcTotalBill() - $scope.calcTotalBill() *  $scope.product.discount/100;
		};
	}
);

//Controller 2 directly created:
billModule.controller("customerController",function($scope)
{
	$scope.customer=
		{
			'name':'Sammy',
			'id':'a1000',
			'mobile':'9779147758'
		}
	}
)

//Controller-1:
//var productControl=function($scope)
/*
{
	$scope.product=
		{
			'cost':0,
			'qty':1,
			'discount':0
		}
	};
	*/

//Controller-2: 
/*
var customerControl=function($scope)
{
	$scope.customer=
		{
			'name':'Sammy',
			'id':'a1000',
			'mobile':'9779147758'
		}
}*/