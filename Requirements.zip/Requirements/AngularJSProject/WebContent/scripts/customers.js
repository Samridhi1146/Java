var custModule=angular.module("custModule",[]);

custModule.run(function($rootScope)
{
	//alert("In custModule.")
	$rootScope.title='Customer Billing';
}
);

custModule.controller("custControl",
		function($scope)
		{
			$scope.customers=
				[
				 	{'name':'Sammy','mobile':'9779147758'},
	                {'name':'Samridhi','mobile':'8360365491'},
	                {'name':'Rahul','mobile':'8284867491'}
				 ];
	}
);
