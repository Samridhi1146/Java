package com.capgemini.traineemanagementsystem.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="TRAINEEMANAGEMENT")
public class TraineeBean 
{
	private Integer traineeId;
	private String traineeName;
	private String traineeLocation;
	private String traineeDomain;
	
	//Getters and setters:
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="traineeId")
	@SequenceGenerator(name="traineeId",sequenceName="trainee_seq")
	@Column(name="trainee_id")
	public Integer getTraineeId() 
	{
		return traineeId;
	}
	public void setTraineeId(Integer traineeId) 
	{
		this.traineeId = traineeId;
	}
	
	@Column(name="trainee_name")
	public String getTraineeName() 
	{
		return traineeName;
	}
	public void setTraineeName(String traineeName) 
	{
		this.traineeName = traineeName;
	}
	
	@Column(name="trainee_location")
	public String getTraineeLocation() 
	{
		return traineeLocation;
	}
	public void setTraineeLocation(String traineeLocation) 
	{
		this.traineeLocation = traineeLocation;
	}
	
	@Column(name="trainee_domain")
	public String getTraineeDomain() 
	{
		return traineeDomain;
	}
	public void setTraineeDomain(String traineeDomain) 
	{
		this.traineeDomain = traineeDomain;
	}
	
	//To string:
	@Override
	public String toString() 
	{
		return "TraineeBean [traineeId=" + traineeId + ", traineeName="
				+ traineeName + ", traineeLocation=" + traineeLocation
				+ ", traineeDomain=" + traineeDomain + "]";
	}	
}