package com.capgemini.traineemanagementsystem.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.traineemanagementsystem.bean.TraineeBean;
import com.capgemini.traineemanagementsystem.service.ITraineeService;

@Controller
public class TraineeController 
{
	@Autowired
	ITraineeService traineeservice;
	
	//For add method:
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addData(@ModelAttribute("my")TraineeBean trainee,Map<String,Object>model)
	{
		List<String> myList=new ArrayList<String>();
		myList.add("JAVA");
		myList.add("Testing");
		myList.add(".NET");
			
		model.put("traineetype",myList);
		return "addTrainee";
	}
	
	@RequestMapping(value="putdata",method=RequestMethod.POST)
	public  ModelAndView dataAdd(@ModelAttribute("my") TraineeBean trainee)
	{
		int traineeId=traineeservice.addTrainee(trainee);
		return new ModelAndView("success", "trainee", traineeId);
	}
	
	//Delete method:
	@RequestMapping(value="delete", method=RequestMethod.GET)
	public String traineeRemove(@ModelAttribute("remove") TraineeBean trainee)
	{
		return "TraineeRemove";
	}
	
	@RequestMapping(value="removedata", method=RequestMethod.POST)
	public ModelAndView removeData(@ModelAttribute("remove") TraineeBean trainee)
	{
		int traineeId = trainee.getTraineeId();
		traineeservice.deleteTrainee(traineeId);
		
		return new ModelAndView("redirect:/Login.jsp");
	}
	
	//Update method:
	@RequestMapping(value="update", method=RequestMethod.GET)
	public String updateData(@ModelAttribute("update") TraineeBean trainee)
	{
		return "UpdateTrainee";
	}
	
	@RequestMapping(value="searchtrainee", method=RequestMethod.POST)
	public ModelAndView searchTrainee(@ModelAttribute("update") TraineeBean trainee, Map<String,Object> model)
	{
		List<String> List= new ArrayList<String>();
		
		List.add("Java");
		List.add("Testing");
		List.add("Mainframe");
		List.add(".NET");
	
		model.put("tType",List);
		
		int traineeId = trainee.getTraineeId();
		List<TraineeBean> traineeList = traineeservice.searchTrainee(traineeId);
		
		return new ModelAndView("Update","trainee",traineeList);
	}
	
	@RequestMapping(value ="putData" , method = RequestMethod.POST)		//This putData should not match any other ones in the prog.
	public String updateTrainee(@ModelAttribute("update")TraineeBean trainee)
	{
		traineeservice.updateTrainee(trainee);
		
		return "redirect:/Login.jsp";
	}

	//Search trainee:
	@RequestMapping(value="search",method=RequestMethod.GET)
	public String searchPage(@ModelAttribute("update") TraineeBean trainee)
	{
		return "TraineeSearch";
	}
		
	@RequestMapping(value="searchdata",method=RequestMethod.POST)
	public ModelAndView searchTrainee(@ModelAttribute("update")TraineeBean trainee)
	{
		int traineeId=trainee.getTraineeId();
		List<TraineeBean> searchData=traineeservice.searchTrainee(traineeId);
		return new ModelAndView("TraineeShow","trainee",searchData);
	}
	
	//For show method:
		@RequestMapping(value="showall",method=RequestMethod.GET)
		public ModelAndView dataShow()
		{ 
			List<TraineeBean> allData=traineeservice.showTrainee();
			return new  ModelAndView("TraineeShow","trainee",allData);
		}
}