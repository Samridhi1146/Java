package com.capgemini.traineemanagementsystem.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.capgemini.traineemanagementsystem.bean.TraineeBean;

@Repository("traineedao")
public class TraineeDAO implements ITraineeDAO
{
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public int addTrainee(TraineeBean trainee) 
	{
		entityManager.persist(trainee);
		entityManager.flush();
		return trainee.getTraineeId();
	}

	@Override
	public void deleteTrainee(int traineeId) 
	{
		Query queryTwo=entityManager.createQuery("DELETE FROM TraineeBean WHERE traineeId=:trainee_id");
		queryTwo.setParameter("trainee_id", traineeId);
		queryTwo.executeUpdate();
	}

	@Override
	public void updateTrainee(TraineeBean trainee) 
	{
		Query queryThree = entityManager.createQuery("Update TraineeBean SET traineeName=:trainee_name,traineeLocation=:trainee_location,traineeDomain=:trainee_domain WHERE traineeId=:trainee_id");
		queryThree.setParameter("mob_id", trainee.getTraineeId());
		queryThree.setParameter("mob_name", trainee.getTraineeName());
		queryThree.setParameter("mob_brand", trainee.getTraineeLocation());
		queryThree.setParameter("mob_price", trainee.getTraineeDomain());
		queryThree.executeUpdate();
	}

	@Override
	public List<TraineeBean> searchTrainee(int traineeId) 
	{
		Query queryFour=entityManager.createQuery("FROM TraineeBean WHERE traineeId=:trainee_id");
		queryFour.setParameter("trainee_id",traineeId);
		List<TraineeBean> mySearch= queryFour.getResultList();
		return mySearch;
	}

	@Override
	public List<TraineeBean> showTrainee() 
	{
		Query queryOne=entityManager.createQuery("FROM TraineeBean"); 
		List<TraineeBean> dataList=queryOne.getResultList();
		return dataList;
	}
}