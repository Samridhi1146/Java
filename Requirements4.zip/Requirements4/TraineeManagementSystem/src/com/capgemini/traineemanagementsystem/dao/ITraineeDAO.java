package com.capgemini.traineemanagementsystem.dao;

import java.util.List;

import com.capgemini.traineemanagementsystem.bean.TraineeBean;

public interface ITraineeDAO 
{
	public int addTrainee(TraineeBean trainee);

	public void deleteTrainee(int traineeId);
	
	public void updateTrainee(TraineeBean trainee);
	
    public List<TraineeBean> searchTrainee(int traineeId);
    
    public List<TraineeBean> showTrainee();
}
