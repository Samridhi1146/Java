package com.capgemini.core.junittest;
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class yo 
{
	@Before
	public void yuuhk()
	{
		
	}
	

	@Test
	public void test() 
	{
		
	}

}
