package com.capgemini.core.junittest;

import static org.junit.Assert.*;

import org.junit.Test;

public class JUnitTest_Purchase 
{
}