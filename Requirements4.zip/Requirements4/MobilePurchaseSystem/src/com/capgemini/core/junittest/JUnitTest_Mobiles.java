package com.capgemini.core.junittest;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.core.beans.PurchaseDetails;
import com.capgemini.core.dao.MobilesdaoImpl;
import com.capgemini.core.exception.MobilesException;

public class JUnitTest_Mobiles 
{
	@Test
	 public void test() throws MobilesException
	 {
		MobilesdaoImpl obj = new MobilesdaoImpl();
		assertEquals(1030, obj.addPurchase(new PurchaseDetails()));
	 }
}