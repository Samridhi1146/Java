package com.capgemini.core.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.core.beans.Mobiles;
import com.capgemini.core.beans.PurchaseDetails;
import com.capgemini.core.exception.MobilesException;
import com.capgemini.core.service.IMobilesService;
import com.capgemini.core.service.MobilesServiceImpl;

public class MyTest 
{
	public static void mainMenu()
	{
		System.out.println("**********************CHOOSE OPTION**********************");
		System.out.println("1. Add new mobile");
		System.out.println("2. Add new purchase entry");
		System.out.println("3. View all available mobiles");
		System.out.println("4. Delete mobile");
		System.out.println("5. Search mobile");
		System.out.println("6. Search mobile based on range");
		System.out.println("7. Update mobiles.");
		System.out.println("8. Exit");
		System.out.println("*********************************************************");
		
		Scanner scr = new Scanner(System.in);
		int choice = scr.nextInt();
		
		//Object of service class is made and implemented below.
		IMobilesService service=new MobilesServiceImpl();
		
		switch (choice) 
		{
			case 1://Add mobile entry.
			int msg=0;
			
			System.out.println("Enter mobile id.");
			int id=scr.nextInt();
			
			String namePattern="[A-Z][a-z]{2,19}";
			
			System.out.println("Enter mobile name.");
			String name=scr.next();
			
			try 
			{
				//Maintain the order.
				MobilesServiceImpl.validateName(name, namePattern);
			} 
			catch (MobilesException e1) 
			{
				System.out.println(e1.getMessage());
				//e1.printStackTrace();
				//break;
			}
			
			System.out.println("Enter mobile price.");
			double price=scr.nextDouble();
			
			System.out.println("Enter mobile quantity.");
			int quantity= scr.nextInt();
			
			Mobiles mobiles=new Mobiles();
			//mobiles is declared above.
			mobiles.setMobileid(id);
			mobiles.setName(name);
			mobiles.setPrice(price);
			mobiles.setQuantity(quantity);
			
			//Calling service layer.
			try 
			{
				//msg declared above in add fn.
				//Object of service class was also created above GLOBALLY.
				msg = service.addMobiles(mobiles);		
			} 
			
			catch (MobilesException e) 
			{
				e.printStackTrace();
				System.out.println(e.getMessage());
			}	
			
			if(msg==1)
			{
				System.out.println("Data inserted.");		
			}
			break;
			
		case 2://Add purchase entry.
			System.out.println("Enter purchase Id : ");
			int purchaseId = scr.nextInt();
			
			System.out.println("Enter purchasing name : ");
			String purchaseName = scr.next();
			
			System.out.println("Enter mail id");
			String purchaseMail = scr.next();
			
			System.out.println("Enter phone number");
			int purchaseNumber = scr.nextInt();
			
//			System.out.println("Enter purchase date");
//			long purchaseDate = scr.nextLong();
			
			System.out.println("Enter mobile id");
			int mobileid = scr.nextInt();
		
			PurchaseDetails pd = new PurchaseDetails();
			pd.setPurchaseid(purchaseId);
			pd.setCname(purchaseName);
			pd.setMailid(purchaseMail);
			pd.setPhoneno(purchaseNumber);
			pd.setMobileid(mobileid);
			
			
			try {
				service.addPurchase(pd);
			}
			
			catch (MobilesException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
						
			break;
			
		case 3://View all mobile entries.
			List<Mobiles> myMobile=null;
			try 
			{
				myMobile = service.viewAll();
			} 
			catch (MobilesException e) 
			{
				System.out.println(e.getMessage());
				e.printStackTrace();
			}
				//Declare mobile1 as mobiles was already declared.
				for (Mobiles mobiles1: myMobile) 		//For each loop or enhanced for loop.
				{
					System.out.println("Name is:"+mobiles1.getMobileid());
					System.out.println("Id is:"+mobiles1.getName());
					System.out.println("Description is:"+mobiles1.getPrice());
					System.out.println("Price is:"+mobiles1.getQuantity());
				}
			break;
			
		case 4://Delete mobile.
			System.out.println("Enter mobile id : ");
			int mobileid1 = scr.nextInt();
			
			try 
			{
				service.removeMobile(mobileid1);
			}
			
			catch (MobilesException e) 
			{
				e.printStackTrace();
			}
			
			break;
			
		case 5://Search mobile.
			System.out.println("Enter mobile Id:");
			int mobileid11=scr.nextInt();
			Mobiles mySearchProd=null;
			try 
			{
			mySearchProd = service.searchMobile(mobileid11);
			} 
			catch (MobilesException e) 
			{
			e.printStackTrace();
			System.out.println(e.getMessage());
			}
			
			//System.out.println("Id is:"+mySearchProd.getProductId());
			System.out.println("Name is:"+mySearchProd.getName());
			System.out.println("Price is:"+mySearchProd.getPrice());
			System.out.println("Description is:"+mySearchProd.getQuantity());
		break;
			
		case 6://Updating mobiles.
//			System.out.println("Enter mobile ID:");
//			mobileid=scr.nextInt();
//			
//			try 
//			{
//				Mobiles mobiles1=service.getMobiles(mobileid);
//				
//				System.out.println("ID:"+mobiles1.getName());
//				System.out.println("Name:" +mobiles1.getPrice());
//				System.out.println("Salary:"+mobiles1.getQuantity());
//				
//				//Updating name:
//				System.out.println("Do you want to update name?(y/n)");
//				char reply=scr.next().charAt(0);		//Method changing.
//				
//				if(reply=='y'||reply=='Y')
//				{
//					System.out.println("Old name="+mobiles1.getName());
//					System.out.println("Provide new name:");
//					mobiles1.setName(scr.next());
//				}
//				
//			System.out.println("\n\n\n");
//			
//			//Updating price:
//			System.out.println("Do you want to update price?(y/n)");
//			reply=scr.next().charAt(0);
//			
//			if(reply=='y'||reply=='Y')
//			{
//				System.out.println("Old price="+mobiles1.getPrice());
//				System.out.println("Provide new price:");
//				mobiles1.setPrice(scr.nextDouble());
//			}
//			
//			//Update quantity:
//			System.out.println("Do you want to update quantity?(y/n)");
//			reply=scr.next().charAt(0);
//			
//			if(reply=='y'||reply=='Y')
//			{
//				System.out.println("Old price="+mobiles1.getName());
//				System.out.println("Provide new price:");
//				mobiles1.setPrice(scr.nextDouble());
//			}
//			//Updating in Database.
//			service.updateMobiles(mobiles1);
//			System.out.println("Employee with:"+mobiles1.getMobileid()+"Updated successfully.");
//			
//			System.out.println("\n\n\n");
//		} 
//			catch (MobilesException e1) 
//			{
//				e1.printStackTrace();
//				System.out.println("Something went wrong. Exception is: "+e1.getMessage());
//			}
//				break;
			
		case 7://Mobile based on a range.
			System.out.println("Enter the lower price");
			 double min = scr.nextDouble();
			 
			 System.out.println("Enter higher price");
			 double max = scr.nextDouble();
			 
			 ArrayList<Mobiles> mobRData = null;
			 try 
			 {
				mobRData = service.viewMobRange(min,max);
			 } 
			
			catch (MobilesException e) 
			 {
				e.printStackTrace();
			 }
		 	for (Mobiles mobile:mobRData)
		 		{
		 			System.out.println(mobile + "\n");	
		 		}
		 	break;
		 	
		case 8://Exit.
			System.out.println("Thank you for choosing us.");
			System.exit(0);
			break;
			
		default:
			break;
		}
	}
}