package com.capgemini.core.ui;

public class MyMain 
{
		public static void main(String[] args) 
		{
			while(true)
			{
				MyTest.mainMenu();
			}
		}
}