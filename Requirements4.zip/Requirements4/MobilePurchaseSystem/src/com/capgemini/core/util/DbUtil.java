 package com.capgemini.core.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.capgemini.core.exception.MobilesException;

public class DbUtil 
{
	private static final Logger myLogger = Logger.getLogger(DbUtil.class);
	static Connection conn=null;					
	public static Connection getConnection() throws MobilesException	
	{
		try 
		{
			FileInputStream fileRead=new FileInputStream("oracle.properties");
			Properties pros=new Properties();
			pros.load(fileRead);
			
			String driver=pros.getProperty("oracle.driver");
			String url=pros.getProperty("oracle.url");
			String uname=pros.getProperty("oracle.username");
			String pass=pros.getProperty("oracle.password");
			
			Class.forName(driver);
			
			conn=DriverManager.getConnection(url,uname,pass);
			System.out.println("Connection established.");
			myLogger.info("Connection established...");
		} 
		catch (IOException | ClassNotFoundException | SQLException e) 
		{
			//System.out.println("Connection not established.");
			e.printStackTrace();
			throw new MobilesException("Connection not established.");
		}
		return conn;		//Connection is returned.
}
}