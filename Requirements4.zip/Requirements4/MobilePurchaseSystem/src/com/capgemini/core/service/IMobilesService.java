package com.capgemini.core.service;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.core.beans.Mobiles;
import com.capgemini.core.beans.PurchaseDetails;
import com.capgemini.core.exception.MobilesException;

public interface IMobilesService 
{
	public int addMobiles(Mobiles prod) throws MobilesException;
	public int addPurchase(PurchaseDetails pd) throws MobilesException;
	public List<Mobiles> viewAll() throws MobilesException;
	public void removeMobile(int mobileid) throws MobilesException;
	public Mobiles searchMobile(int mobileid) throws MobilesException;
	public ArrayList<Mobiles> viewMobRange(double low , double high) throws MobilesException;
}