package com.capgemini.core.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import com.capgemini.core.beans.Mobiles;
import com.capgemini.core.beans.PurchaseDetails;
import com.capgemini.core.dao.IMobilesdao;
import com.capgemini.core.dao.MobilesdaoImpl;
import com.capgemini.core.exception.MobilesException;

public class MobilesServiceImpl implements IMobilesService
{
	IMobilesdao daoObject=new MobilesdaoImpl();
	@Override
	public int addMobiles(Mobiles mobiles) throws MobilesException 
	{
		//Object of dao class and mobiles is object of class.
		return daoObject.addMobiles(mobiles);		//Calling add from DAO layer.
	}
	
	@Override
	public int addPurchase(PurchaseDetails pd) throws MobilesException
	{
		return daoObject.addPurchase(pd);
	}
	
	@Override
	public List<Mobiles> viewAll() throws MobilesException 
	{
		return daoObject.viewAll();
	}
	
	@Override
	public void removeMobile(int mobileid) throws MobilesException 
	{
		daoObject.removeMobile(mobileid);
	}

	@Override
	public Mobiles searchMobile(int mobileid) throws MobilesException 
	{
		return daoObject.searchMobile(mobileid);
	}
	
	@Override
	public ArrayList<Mobiles> viewMobRange(double low, double high) throws MobilesException 
	{
		return  daoObject.viewMobRange(low,high);
	}
	
	public static boolean validateName(String name,String namePattern) throws MobilesException
	{
		boolean validation=Pattern.matches(namePattern,name);
		
		if(!validation)	
		{
			throw new MobilesException("First letter shold be in caps. Min=3,Max=20");
		}
		return validation;
	}
	
}