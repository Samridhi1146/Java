package com.capgemini.core.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.core.beans.Mobiles;
import com.capgemini.core.beans.PurchaseDetails;
import com.capgemini.core.exception.MobilesException;
import com.capgemini.core.util.DbUtil;

//Implement interface of dao.
public class MobilesdaoImpl implements IMobilesdao
{
	private static final Logger mylog = Logger.getLogger(MobilesdaoImpl.class);
	//Needs to be written globally.
	static Connection con=null;
	static PreparedStatement pstm=null;
	int status=0;
	
	@Override
	public int addMobiles(Mobiles mobiles) throws MobilesException 
	{
		//Status method is here.
		int status=0;
		//con is declared above.
		con=DbUtil.getConnection();
		//Put up the number of question marks as required.
		String query="INSERT INTO Mobiles VALUES(?,?,?,?)";
		
		try 
		{
			//Database part.
			pstm=con.prepareStatement(query);
			
			pstm.setInt(1,mobiles.getMobileid());
			pstm.setString(2,mobiles.getName());
			pstm.setDouble(3,mobiles.getPrice());
			pstm.setInt(4,mobiles.getQuantity());
			
			status=pstm.executeUpdate();		//Return type of execute update-integer.
			mylog.info("data inserted "+mobiles.getMobileid());
			
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
			throw new MobilesException("Problem in Adding product.");
		}
		finally
		{
			try 
			{
				pstm.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
		return status;
	}
	
	@Override
	public int addPurchase(PurchaseDetails pd) throws MobilesException 
	{
		status = 0;
		int sammy=0;
		
		Connection conn = DbUtil.getConnection();
		PreparedStatement pstm=null;
		
		String queryone = "INSERT INTO purchasedetails VALUES(?,?,?,?,?)";
		try {
			pstm = conn.prepareStatement(queryone);
			

			int id = MobilesdaoImpl.getPurchaseId();
			java.sql.Date date = new java.sql.Date(Calendar.getInstance().getTime().getTime());	
			
			pstm.setInt ( 1,id );
			pstm.setString( 2 , pd.getCname() );
			pstm.setString( 3 , pd.getMailid());
			pstm.setLong( 4 , pd.getPhoneno());
			//pstm.setDate( 5 , date );
			pstm.setInt( 5 , pd.getMobileid() );
			
			status = pstm.executeUpdate();
			
			if(status > 0)
				// status = id ;
				sammy=id;
		} 
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new MobilesException("Purchase details invalid...");
		}
		
		
		
		return sammy;
	}

	private static int getPurchaseId() throws MobilesException 
	{
		int id=0;
		
		try {
			con=DbUtil.getConnection();
			String query = "SELECT purchase_details_seq.nextval FROM DUAL";
			pstm =  con.prepareStatement(query);
			ResultSet rs = pstm.executeQuery();
			
			if(rs.next())
			{
				id = rs.getInt(1);
			}
		} 
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		finally
		{
			try {
				pstm.close();
				con.close();
			} 
			
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return id;
	}

	@Override
	public List<Mobiles> viewAll() throws MobilesException
	{
		List<Mobiles>myList=new ArrayList<Mobiles>();
		
		con=DbUtil.getConnection();
		String queryTwo="SELECT mobileid,name,price,quantity FROM MOBILES";
		try 
		{
			pstm=con.prepareStatement(queryTwo);
			ResultSet res=pstm.executeQuery();
			
			while(res.next())
			{
				Mobiles mobiles=new Mobiles();
				
				mobiles.setMobileid(res.getInt("mobileid"));
				mobiles.setName(res.getString("name"));
				mobiles.setPrice(res.getDouble("price"));
				mobiles.setQuantity(res.getInt("quantity"));
				
				myList.add(mobiles);
			} 
		}
		
		catch (SQLException e) 
		{
			e.printStackTrace();
			throw new MobilesException("Problem in Show All.");
		}
		finally
		{
			try 
			{
				pstm.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
		return myList;
	}
	
	@Override
	public void removeMobile(int mobileid) throws MobilesException
	{
		Connection conn = DbUtil.getConnection();
		String queryfour = "DELETE FROM mobiles WHERE mobileid=?";
		
		try 
		{
			pstm=conn.prepareStatement(queryfour);
			
			pstm.setInt(1,mobileid);
			
			int status = pstm.executeUpdate();
			
			if(status == 1)
				System.out.println("Record deleted successfully");
		} 
		
		catch (SQLException e) 
		{
			e.printStackTrace();
			throw new MobilesException("Mobile does not exist..");
		}
	}

	@Override
	public Mobiles searchMobile(int mobileid) throws MobilesException 
	{
		Mobiles mSearch=null;
		try 
		{
			con=DbUtil.getConnection();
			String queryThree="SELECT mobileid,name,price,quantity FROM MOBILES WHERE mobileid=?";
			pstm=con.prepareStatement(queryThree);
			pstm.setInt(1,mobileid);
			ResultSet resOne=pstm.executeQuery();
			
			while(resOne.next())
			{
				mSearch=new Mobiles();
			
				mSearch.setName(resOne.getString("name"));
				mSearch.setPrice(resOne.getDouble("price"));
				mSearch.setQuantity(resOne.getInt("quantity"));
			}
		} 
		catch (MobilesException | SQLException e) 
		{
			e.printStackTrace();
			throw new MobilesException("Problem in search.");
		}
		finally
		{
			try 
			{
				pstm.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
		return mSearch;
	}
	public ArrayList<Mobiles> viewMobRange(double low, double high) throws MobilesException
	{
		Connection conn = DbUtil.getConnection();
		String queryfive = "SELECT * FROM mobiles WHERE price > ? AND price < ?";
		
		ArrayList<Mobiles> mobRData=null;
		
		try {
			pstm=conn.prepareStatement(queryfive);
			pstm.setDouble(1, low);
			pstm.setDouble(2, high);
			mobRData = new ArrayList();
			Mobiles mob=null;

			ResultSet rsRange = pstm.executeQuery();
			while(rsRange.next())
			{
				mob= new Mobiles();
				mob.setMobileid(rsRange.getInt(1));
				mob.setName(rsRange.getString(2));
				mob.setPrice(rsRange.getDouble(3));
				mob.setQuantity(rsRange.getInt(4));
				mobRData.add(mob);
			}
		} 
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new MobilesException("No mobile found..");
		}
		return mobRData ;
	}
	
	//Functions for update:
	@Override
	public Mobiles getMobiles(int mobileid) throws MobilesException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void updateMobiles(Mobiles mobiles) throws MobilesException {
		// TODO Auto-generated method stub
		
	}
}