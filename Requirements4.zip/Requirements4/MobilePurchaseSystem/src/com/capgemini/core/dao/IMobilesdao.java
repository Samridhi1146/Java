package com.capgemini.core.dao;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.core.beans.Mobiles;
import com.capgemini.core.beans.PurchaseDetails;
import com.capgemini.core.exception.MobilesException;

public interface IMobilesdao 
{
	//For adding into data.Change name of object to mobiles.
	public int addMobiles(Mobiles mobiles) throws MobilesException;
	public int addPurchase(PurchaseDetails pd) throws MobilesException;
	public List<Mobiles> viewAll() throws MobilesException;
	public void removeMobile(int mobileid) throws MobilesException;
	public Mobiles searchMobile(int mobileid) throws MobilesException;
	public Mobiles getMobiles(int mobileid) throws MobilesException;
	public void updateMobiles(Mobiles mobiles) throws MobilesException;
	public ArrayList<Mobiles> viewMobRange(double low , double high) throws MobilesException;
}