package com.cg.payroll.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.payroll.beans.Employee;
import com.cg.payroll.exceptions.EmployeeDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;

@Controller
public class EmployeeController {
	
	@Autowired
	PayrollServices service;
	
	@RequestMapping(value="add" , method=RequestMethod.GET)
	public String addData(@ModelAttribute("my") Employee emp, Map<String,Object> model)
	{
		return "formPage";
		
	}
	
	@RequestMapping(value="putData", method=RequestMethod.POST)
	public String dataAdd(@ModelAttribute("my") Employee emp) throws PayrollServicesDownException, SQLException, EmployeeDetailsNotFoundException
	{
		service.acceptEmployeeDetails(emp);
		return "index";
		
	}
	
	//searching trainee
		@RequestMapping(value="searchEmployee", method=RequestMethod.POST)
		public ModelAndView searchEmployee(@ModelAttribute("mysearch") Employee emp, Map<String,Object> model) throws EmployeeDetailsNotFoundException, PayrollServicesDownException, SQLException
		{
			int empId = emp.getEmpId();
			Employee mySearch = service.getEmployeeDetails(empId);
			return new ModelAndView("show", "employee", mySearch);
			
		}
	
	@RequestMapping(value="showAll", method=RequestMethod.GET)
	public ModelAndView showData() throws PayrollServicesDownException, SQLException
	{
		List<Employee> dataList=service.getAllEmployeeDetails();
		
		return new ModelAndView("show", "employee", dataList);
		
	}
	
	//directed to search jsp
	
	//directed to delete
	@RequestMapping(value="delete", method=RequestMethod.GET)
	public String employeeRemove(@ModelAttribute("mysearch") Employee emp)
	{
		return "remove";
		
	}
	
	//delete
	@RequestMapping(value="removedata", method=RequestMethod.GET)
	public String removeData(@RequestParam("id")Integer id) throws SQLException
	{
		service.removeEmployee(id);
		return "index";
	}
	
	// directed to update jsp
	@RequestMapping(value="update", method=RequestMethod.GET)
	public String updateEmployee(@RequestParam("id")Integer id, Map<String,Object> model, @ModelAttribute("data")Employee employee) throws EmployeeDetailsNotFoundException, PayrollServicesDownException, SQLException
	{
		employee = service.getEmployeeDetails(id);
		model.put("data", employee);
		
		return "update";
	}
	//update
	@RequestMapping(value ="putdata" , method = RequestMethod.POST)
	public String updateData(@ModelAttribute("mysearch")Employee emp)
	{
		
		return "index";
		
	}
	
}
