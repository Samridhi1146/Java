package com.cg.payroll.services;

import java.sql.SQLException;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.payroll.beans.Employee;
import com.cg.payroll.daoservices.Dao;
import com.cg.payroll.exceptions.EmployeeDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
@Service("service")
@Transactional
public class PayrollServicesImpl implements PayrollServices {

	@Autowired
	Dao dao;
	
	@Override
	public void acceptEmployeeDetails(Employee employee)
			throws PayrollServicesDownException, SQLException {
		dao.insertEmployee(employee);
	}

	
	@Override
	public Employee getEmployeeDetails(int employeeid)
			throws EmployeeDetailsNotFoundException,
			PayrollServicesDownException, SQLException 
	{
		return dao.getEmployee(employeeid);
	}

	@Override
	public List<Employee> getAllEmployeeDetails()
			throws PayrollServicesDownException, SQLException {
		return dao.getAllEmployees();
	}

	@Override
	public void removeEmployee(int empId) throws SQLException {
		dao.deleteEmployee(empId);
		
	}

}
