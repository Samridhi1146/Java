package com.capgemini.appl.entities;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity(name="dept")
@Table(name="DEPT")
public class Dept 
{
	private int deptNo;
	private String deptName;
	private String location;
	
	public Dept() 
	{
		
	}

	//Association reference:
	private Set<Emp> empList;
	
	public Dept(int deptNo, String deptName, String location) {
		super();
		this.deptNo = deptNo;
		this.deptName = deptName;
		this.location = location;
	}

	

	@Override
	public String toString() {
		return "Dept [deptNo=" + deptNo + ", deptName=" + deptName
				+ ", location=" + location + "]";
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((deptName == null) ? 0 : deptName.hashCode());
		result = prime * result + deptNo;
		result = prime * result
				+ ((location == null) ? 0 : location.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Dept other = (Dept) obj;
		if (deptName == null) {
			if (other.deptName != null)
				return false;
		} else if (!deptName.equals(other.deptName))
			return false;
		if (deptNo != other.deptNo)
			return false;
		if (location == null) {
			if (other.location != null)
				return false;
		} else if (!location.equals(other.location))
			return false;
		return true;
	}

	@Id
	@Column(name="DEPTNO")
	public int getDeptNo()
	{
		return deptNo;
	}

	public void setDeptNo(int deptNo) 
	{
		this.deptNo = deptNo;
	}

	@Column(name="DNAME")
	public String getDeptName()
	{
		return deptName;
	}

	public void setDeptName(String deptName) 
	{
		this.deptName = deptName;
	}

	@Column(name="LOC")
	public String getLocation() 
	{
		return location;
	}

	public void setLocation(String location)
	{
		this.location = location;
	}
	
	@OneToMany(mappedBy="dept")				//Name of the property which owns and exercises the relationship.
	public Set<Emp> getEmpList() 
	{
		return empList;
	}

	public void setEmpList(Set<Emp> empList) 
	{
		this.empList = empList;
	}
}