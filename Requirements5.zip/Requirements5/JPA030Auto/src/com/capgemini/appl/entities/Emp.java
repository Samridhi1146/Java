package com.capgemini.appl.entities;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

//Emp class is the relationship owner of the relation between Emp and Dept.
@Entity(name="employees")					//All annotations from persistence.
@Table(name="EMP")
@NamedQueries
({
	//Below are named parametrised queries:
	@NamedQuery(name="listEmpsOfSalRange",query="SELECT e FROM  employees e WHERE e.empSal between :pFrom and :pTo"),
	@NamedQuery(name="listAllEmps",query="SELECT e FROM employees e")
})
@SequenceGenerator(name="emp_generator",sequenceName="seq_emps",allocationSize=1,initialValue=1)

public class Emp 
{
	private int empNo;
	private String empNm;
	private float empSal;
	
	//For association:
	private Dept dept;
	
	//Parametrized constructor:
	public Emp(int empNo, String empNm, float empSal) 
	{
		super();
		this.empNo = empNo;
		this.empNm = empNm;
		this.empSal = empSal;
	}

	//Constructor without empId:
	public Emp(String empNm, float empSal) 
	{
		super();
		this.empNm = empNm;
		this.empSal = empSal;
	}
	//Parameter-less constructor:
	public Emp() 
	{
		super();
	}

	//Getters setters:
	@Id						//Represents identity value.
	@Column(name="EMPNO")
	@GeneratedValue(generator="emp_generator",strategy=GenerationType.SEQUENCE)	   //Suggests that this attribute will be auto-generated.
	public int getEmpNo() 				//Property name=empNo(Only 1st alphabet's case is changed-that is property name).
	{
		return empNo;
	}
	public void setEmpNo(int empNo) 
	{
		this.empNo = empNo;
	}
	
	@Column(name="ENAME")
	public String getEmpNm() 			//Property Name-empNm.
	{
		return empNm;
	}
	public void setEmpNm(String empNm) 
	{
		this.empNm = empNm;
	}

	@Column(name="SAL")
	public float getEmpSal() 			//Property Name-empSal.
	{
		return empSal;
	}
	public void setEmpSal(float empSal) 
	{
		this.empSal = empSal;
	}
						
	@OneToOne							//(cascade=CascadeType.ALL)
	@JoinColumn(name="deptNo")
	public Dept getDept() 				//dept-Property name of attribute.
	{
		return dept;
	}

	public void setDept(Dept dept) 
	{
		this.dept = dept;
	}

	//To string:
	@Override
	public String toString() {
		return "Emp [empNo=" + empNo + ", empNm=" + empNm + ", empSal="
				+ empSal + ", dept=" + dept + "]";
	}

	//Hash code:
	@Override
	public int hashCode() 
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + ((empNm == null) ? 0 : empNm.hashCode());
		result = prime * result + empNo;
		//result = prime * result + Float.floatToIntBits(empSal);
		return result;
	}

	//Equals method:
	@Override
	public boolean equals(Object obj) 
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Emp other = (Emp) obj;
		if (empNm == null) 
		{
			if (other.empNm != null)
				return false;
		} 
		else if (!empNm.equals(other.empNm))
			return false;
		if (empNo != other.empNo)
			return false;
		if (Float.floatToIntBits(empSal) != Float.floatToIntBits(other.empSal))
			return false;
		return true;
	}
}