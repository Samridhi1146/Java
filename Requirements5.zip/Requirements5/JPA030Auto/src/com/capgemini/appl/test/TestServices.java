package com.capgemini.appl.test;

import java.util.List;

import com.capgemini.appl.entities.Dept;
import com.capgemini.appl.entities.Emp;
import com.capgemini.appl.exceptions.CustomException;
import com.capgemini.appl.services.EmpServicesImpl;
import com.capgemini.appl.services.IEmpServices;

public class TestServices 
{
	public static void main(String[] args) 
	{
		IEmpServices services=new EmpServicesImpl();
		/*
		//Addition by auto-generation:
		//Insertion:
		try 
		{
			Emp emp=new Emp("Samridhi",1000);
			services.addNewEmp(emp);
			//Gives new Id to emp in syso as well as in addNewEmp.
			System.out.println(emp);
		} 
		catch (CustomException e) 
		{
			e.printStackTrace();
		}
		*/
		
		/*
		//Viewing employee details:
		Emp emp=services.getEmpDetails(7698);
		System.out.println(emp);
		System.out.println(emp.getEmpNo());
		System.out.println(emp.getDept().getDeptName());
		System.out.println(emp.getDept().getLocation());
		*/
		
		//Viewing department details-We don't get employee details. This is a unidirectional relationship.
		try
		{
			Dept dept=services.getDeptDetails(10);
			System.out.println(dept);
			for(Emp emp:dept.getEmpList())
			{
				System.out.println(emp);
			}
		} 
		catch (CustomException e) 
		{
			e.printStackTrace();
		}
	}
}