package com.capgemini.appl.test;

import java.util.List;

import com.capgemini.appl.entities.Emp;
import com.capgemini.appl.exceptions.CustomException;
import com.capgemini.appl.services.EmpServicesImpl;
import com.capgemini.appl.services.IEmpServices;

public class TestServices 
{
	public static void main(String[] args) 
	{
		IEmpServices services=new EmpServicesImpl();
		/*
		Emp emp=services.getEmpDetails(7521);
		System.out.println(emp);
		
		
		List<Emp> empList=services.getAllEmps();
		for(Emp emp1:empList)
		{
			System.out.println(emp1);
		}
		
		//Insertion:
		/*
		try 
		{
			Emp emp=new Emp(9001,"Samridhi",1000);
			services.addNewEmp(emp);
		} 
		catch (CustomException e) 
		{
			e.printStackTrace();
		}
		
		
		//Update: Requires to uncomment list also.
		try 
		{
			services.updateName(9000,"Rahul");
			System.out.println("Record updated.");
		}
		catch (CustomException e) 
		{
			e.printStackTrace();
		}	
		
		try 
		{
			Emp emp=new Emp(9001,"Sammy",6000);
			services.updateRecord(emp);
			System.out.println("Record updated.");
		}
		catch (CustomException e) 
		{
			e.printStackTrace();
		}	
		*/
		
		//Employees on a range:
		
		try 
		{
			List<Emp> empList=services.getEmpsOnSalRange(5000,10000);
			for(Emp emp:empList)
			{
				System.out.println(emp);
			}
		}
		catch (CustomException e) 
		{
			e.printStackTrace();
		}
	}
}