package com.capgemini.appl.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.capgemini.appl.entities.Emp;
import com.capgemini.appl.util.JpaUtil;

public class TestObjectStates 
{
	public static void main(String[] args) 
	{
		EntityManager manager=JpaUtil.getEntityManager();
		EntityTransaction trans=null;
		

		try 
		{
			 trans = manager.getTransaction();
			//Object 1:					//Viewing an entry:
//			trans.begin();
//			Emp emp = manager.find(Emp.class, 7934);  	 //emp is persistent object made by manager and change will be shown in table
//			System.out.println(emp);
//		    emp.setEmpNm("MILLER*");                 	 //Firing update query

//		    Emp emp1 = new Emp(9000,"Chandra",15000); 	 // transient object which is not made by manager 
//		    manager.persist(emp1);                   	 //Converts transient object to persistent object
//		    trans.commit();

//		    trans.begin();
//		    emp1.setEmpNm("Chandra*");                 	 // Finally changed to persistent object
//		    System.out.println(emp1);
//		    trans.commit();
//		}
//		catch (Exception e) 
//		{
//			trans.rollback();
//			e.printStackTrace();
//		}
//		
		//Object 2:										 //Deleting an object.
//		 trans.begin();
//		 Emp emp = manager.find(Emp.class, 7934);
//		 if(emp != null)
//		 {
			 //Transient object:
//			 manager.remove(emp);
//			 System.out.println("record deleted..");
//		 }
//		else
//		{
//			 System.out.println("Record missing for deletion.");
//		 }
//		 trans.commit();
//		 trans.begin();
//		 emp.setEmpNm("Chandra*");
//		 trans.commit();
//	}
//		catch (Exception e) 
//		{
//		trans.rollback();
//			e.printStackTrace();
//		}

		//Object 3:	 											//Detach block-update query will not work here.
		 trans.begin();
		 Emp emp = manager.find(Emp.class,7876);
		 System.out.println(emp);
		 
		 //Detaching:
		 manager.detach(emp);
		 emp.setEmpNm("Chandra");
		 trans.commit();
		} 
		catch (Exception e) 
		{
		trans.rollback();
		e.printStackTrace();
		}
	}
}