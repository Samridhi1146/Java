package com.capgemini.appl.test;

import java.util.List;

import com.capgemini.appl.dao.EmpDaoImpl;
import com.capgemini.appl.entities.Emp;

public class TestJPA 
{
	public static void main(String[] args) 
	{
		EmpDaoImpl impl=new EmpDaoImpl();
		//Single record from DB:
		Emp emp=impl.getEmpDetails(7499);
		System.out.println(emp);
		
		//Multiple records from DB:
		System.out.println("Listof employees from the table:");
		List<Emp> empList=impl.getAllEmps();
		
		for(Object emp1:empList)
		{
			System.out.println(emp1);		//Because we don't need object,we need the Employee class variables,
											//we type cast it to employee object again.
		}
	}
}