package com.capgemini.appl.test;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.appl.entities.Emp;
import com.capgemini.appl.services.EmpServicesImpl;
import com.capgemini.appl.services.IEmpServices;

public class TestJUnit 
{
	private static IEmpServices services=null;

	@BeforeClass
	public static void initialize()
	{
		services=new EmpServicesImpl();
	}
	
	@Test
	public void testExistingEmp()
	{
		Emp expected=new Emp(7369,"SMITH",800);
		Emp actual=services.getEmpDetails(7369);
		
		Assert.assertEquals(expected,actual);
	}
	
	@AfterClass
	public static void cleanUp()
	{
		services=null;
	}
}