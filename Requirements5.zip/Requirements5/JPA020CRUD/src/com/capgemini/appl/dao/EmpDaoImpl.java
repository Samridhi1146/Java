package com.capgemini.appl.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.capgemini.appl.entities.Emp;
import com.capgemini.appl.exceptions.CustomException;
import com.capgemini.appl.util.JpaUtil;

public class EmpDaoImpl implements IEmpDao
{
	//Instance variable:
	//EntityManagerFactory factory=null;
	//Reference:
	private EntityManager manager;
	
	public EmpDaoImpl()
	{
		//Call super first in constructor.
		super();
		//Factory created,gives entity manager and creates pool of connections.
		//EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-SK");
		manager=JpaUtil.getEntityManager();
	}
		//CRUD operation for employee details:
		public Emp getEmpDetails(int empNo)
		{
			Emp emp=manager.find(Emp.class,empNo);
			return emp;
		}
		
		//Executes automatically during garbage collection after code is done. This is automatically always executed.
		public void closeFactory()
		{
			//factory.close();
			JpaUtil.close();
		}
		
		public List<Emp> getAllEmps()
		{
			//This query is known as JPA-QL(Query Language).
			//Query qry=manager.createQuery("SELECT e FROM Emp e");
			
			TypedQuery<Emp> qry = manager.createNamedQuery("listAllEmps", Emp.class);
			List<Emp> empList=(List<Emp>)qry.getResultList();
			return empList;
			
			//Query qry=manager.createQuery("SELECT e.empNo,e.empNm,e.empSal FROM Emp e");
			//This above can not be used as we used a reference variable "e".
			
			//Query qry=manager.createQuery("SELECT FROM employees e");
			//Above code can also be used if we use a reference variable of entity in beans. 
			//It is not optional,is is important to use this line. Only the reference entity object will be written above.
		}
		//Override methods-choose finalize.
		@Override
		protected void finalize() throws Throwable 
		{
			JpaUtil.close();
			//closeFactory();
			//Call super here in exact opposite order of constructor:
			super.finalize();
		}
		
		@Override
		public void addNewEmp(Emp emp) throws CustomException
		{
			//EntityTransaction used as a reference.
			EntityTransaction trans=manager.getTransaction();
			trans.begin();
			Emp empExist=getEmpDetails(emp.getEmpNo());
			
			if(empExist!=null)
			{
				throw new CustomException("Duplicate employee record. Insertion denied.");
			}
			else
			{
				manager.persist(emp);
			}
			trans.commit();
		}
		@Override
		public void updateName(int empNo,String empNm) throws CustomException
		{
			EntityTransaction trans=manager.getTransaction();
			trans.begin();
			Emp emp=getEmpDetails(empNo);
			if(emp!=null)
			{
				emp.setEmpNm(empNm);	
			}
			else
			{
				throw new CustomException("Given employee Id is wrong.");
			}
			trans.commit();
		}
		@Override
		public void updateRecord(Emp emp) throws CustomException 
		{
			EntityTransaction trans=manager.getTransaction();
			trans.begin();
			
			//Persistent object emp1.
			Emp emp1=getEmpDetails(emp.getEmpNo());
			if(emp1!=null)
			{
				manager.merge(emp);						//Merging new data of emp with emp1.
			}
			else
			{
				throw new CustomException("Given employee Id is wrong.");
			}
			trans.commit();
		}
		
		@Override
		public List<Emp> getEmpsOnSalRange(float from, float to) throws CustomException 
		{
			//This is a JPA-QL:
			//Transaction need not be managed as data is inserted in it.
			//Query qry=manager.createQuery("SELECT e FROM  employees e WHERE e.empSal between  ?1 and ?2");
			
			//Below query is now in Emp. Under Named query.
			//String query="SELECT e FROM  employees e WHERE e.empSal between  ?1 and ?2";
			//String query="";
			
			//Below query works in the same way as above.
			TypedQuery<Emp> qry=manager.createNamedQuery("listEmpsOfSalRange",Emp.class);

			qry.setParameter("pFrom",from);
			qry.setParameter("pTo",to);
			List<Emp> empList=(List<Emp>)qry.getResultList();
			return empList;
		}
}