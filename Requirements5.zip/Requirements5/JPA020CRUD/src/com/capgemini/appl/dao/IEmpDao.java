package com.capgemini.appl.dao;

import java.util.List;

import com.capgemini.appl.entities.Emp;
import com.capgemini.appl.exceptions.CustomException;

public interface IEmpDao 
{
	Emp getEmpDetails(int empNo);
	
	List<Emp> getAllEmps();
	
	public void addNewEmp(Emp emp) throws CustomException;
	
	public void updateName(int empNo,String empNm) throws CustomException;
	
	public void updateRecord(Emp emp) throws CustomException;
	
	List<Emp> getEmpsOnSalRange(float from,float to) throws CustomException;
}