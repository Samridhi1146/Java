package com.capgemini.appl.services;

import java.util.List;

import com.capgemini.appl.dao.EmpDaoImpl;
import com.capgemini.appl.dao.IEmpDao;
import com.capgemini.appl.entities.Emp;
import com.capgemini.appl.exceptions.CustomException;

public class EmpServicesImpl implements IEmpServices
{
	private IEmpDao dao;
	
	public EmpServicesImpl()
	{
		dao=new EmpDaoImpl();
	}

	@Override
	public Emp getEmpDetails(int empNo) 
	{
		return dao.getEmpDetails(empNo);
	}

	@Override
	public List<Emp> getAllEmps() 
	{
		return dao.getAllEmps();
	}

	@Override
	public void addNewEmp(Emp emp) throws CustomException 
	{
		dao.addNewEmp(emp);
	}

	@Override
	public void updateName(int empNo, String empNm) throws CustomException 
	{
		dao.updateName(empNo,empNm);
	}

	@Override
	public void updateRecord(Emp emp) throws CustomException 
	{
		dao.updateRecord(emp);	
	}

	@Override
	public List<Emp> getEmpsOnSalRange(float from, float to) throws CustomException 
	{
		return dao.getEmpsOnSalRange(from,to);
	}
}