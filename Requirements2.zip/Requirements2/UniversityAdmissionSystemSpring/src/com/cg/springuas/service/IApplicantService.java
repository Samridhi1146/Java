package com.cg.springuas.service;

import java.util.ArrayList;
import java.util.List;

import org.jboss.resteasy.spi.ApplicationException;
import org.w3c.dom.ls.LSInput;

import com.cg.springuas.bean.Application;
import com.cg.springuas.bean.ProgramsOffered;


public interface IApplicantService{


	public int addApplicant(Application app) throws ApplicationException;
	
	public List<Application> viewApplication(int applicationid) throws ApplicationException;
	
	public List<Application> getAllApplications() throws ApplicationException;
	
	public List<ProgramsOffered> getAllPrograms() throws ApplicationException;
	
	public void update(Application app) throws ApplicationException;
	
	public void update(ProgramsOffered prog) throws ApplicationException;
	
	public ProgramsOffered viewProgram(String programName);
	
	public void deleteProgramsOffered(String progName);
	
	public String addProgram(ProgramsOffered prog) throws ApplicationException;
	
	public String getRole(String loginid, String pass);
	
	public Application findApplication(int id);
	
	public ProgramsOffered findProgram(String progName);
}
