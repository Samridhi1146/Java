package com.cg.springuas.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.jboss.resteasy.spi.ApplicationException;
import org.springframework.stereotype.Repository;

import com.cg.springuas.bean.Application;
import com.cg.springuas.bean.ProgramsOffered;
import com.cg.springuas.bean.Users;


@Repository("applicationDao")
public class ApplicantDAOImpl implements IApplicantDAO
{

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public String getRole(String loginid, String pass) 
	{
		String query = "SELECT b from USERS b where b.loginid =:LOGIN_ID AND b.password =:PASSWORD";
		TypedQuery<Users> queryOne = entityManager.createQuery(query, Users.class);
		queryOne.setParameter("LOGIN_ID", loginid );
		queryOne.setParameter("PASSWORD", pass);
		
		Users usr = queryOne.getSingleResult();
		
		return usr.getRole();
	}
	
	@Override
	public int addApplicant(Application app) throws ApplicationException 
	{
		entityManager.persist(app);
		entityManager.flush();
		return app.getApplicationId();
	}


	@Override
	public List<Application> viewApplication(int applicationid)throws ApplicationException 
	{
		Query queryTwo = entityManager.createQuery("From APPLICATION where applicationId=:application_id");
		queryTwo.setParameter("application_id", applicationid);
		List<Application> searchApplication = queryTwo.getResultList();
		return searchApplication;
	}

	@Override
	public List<Application> getAllApplications() throws ApplicationException 
	{
		
		Query queryTwo = entityManager.createQuery("From APPLICATION");
		List<Application> dataList = queryTwo.getResultList();
		return dataList;
	}
	
	@Override
	public List<ProgramsOffered> getAllPrograms() throws ApplicationException 
	{
		
		Query queryThree = entityManager.createQuery("From PROGRAMS_OFFERED");
		List<ProgramsOffered> progList = queryThree.getResultList();
		return progList;
	}

	@Override
	public void update(Application app) throws ApplicationException 
	{
		Query queryFour = entityManager.createQuery("Update APPLICATION Set applicationId=:application_id, fullName=:full_name,dob=:date_of_birth,highestQual=:highest_qualification,marks=:marks_obtained,goals=:goals,emailId=:email_id,status=:status,doi=:date_of_interview where applicationId=:application_id");
		queryFour.setParameter("application_id", app.getApplicationId());
		queryFour.setParameter("full_name", app.getFullName());
		queryFour.setParameter("date_of_birth", app.getDob());
		queryFour.setParameter("highest_qualification", app.getHighestQual());
		queryFour.setParameter("marks_obtained", app.getMarks());
		queryFour.setParameter("goals", app.getGoals());
		queryFour.setParameter("email_id", app.getEmailId());
		queryFour.setParameter("status", app.getStatus());
		queryFour.setParameter("date_of_interview", app.getDoi());
		queryFour.executeUpdate();
		
	}

	@Override
	public void update(ProgramsOffered prog) throws ApplicationException 
	{
		Query queryFour = entityManager.createQuery("Update PROGRAMS_OFFERED Set programName=:program_name, description=:description,applicantEligibility=:applicant_eligibility,duration=:duration,degreeOffered=:degree_certificate_offered where programName=:program_name");
		queryFour.setParameter("program_name", prog.getProgramName());
		queryFour.setParameter("description", prog.getDescription());
		queryFour.setParameter("applicant_eligibility", prog.getApplicantEligibility());
		queryFour.setParameter("duration", prog.getDuration());
		queryFour.setParameter("degree_certificate_offered", prog.getDegreeOffered());
		queryFour.executeUpdate();
		
	}

	@Override
	public ProgramsOffered viewProgram(String programName) 
	{
		ProgramsOffered prog = entityManager.find(ProgramsOffered.class, programName);
		return prog;
	}

	@Override
	public void deleteProgramsOffered(String progName)
	{
		ProgramsOffered prog = entityManager.find(ProgramsOffered.class, progName);
		entityManager.remove(prog);
		
	}

	@Override
	public String addProgram(ProgramsOffered prog) throws ApplicationException 
	{
		entityManager.persist(prog);
		entityManager.flush();
		return prog.getProgramName();
		
	}

	@Override
	public Application findApplication(int id) 
	{
		Query queryFive = entityManager.createQuery("From APPLICATION where applicationId =:application_id");
		queryFive.setParameter("application_id", id);
		Application app = (Application) queryFive.getSingleResult();
		return app;
	}

	@Override
	public ProgramsOffered findProgram(String progName) {
		
		Query querySix = entityManager.createQuery("From PROGRAMS_OFFERED where programName=:program_name");
		querySix.setParameter("program_name", progName);
		ProgramsOffered prog =  (ProgramsOffered) querySix.getSingleResult();
		return prog;
	}


	

}
