package com.cg.banking.services;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServices;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;


public class BankingServicesImpl implements BankingServices {

	@Override
	public long openAccount(int customerId, String accountType,
			float initBalance) throws InvalidAmountException,
			CustomerNotFoundException, InvalidAccountTypeException,
			BankingServicesDownException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public float depositAmount(int customerId, int accountNo, float amount)
			throws CustomerNotFoundException, AccountNotFoundException,
			BankingServicesDownException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public float withdrawAmount(int customerId, int accountNo, float amount,
			int pinNumber) throws InsufficientAmountException,
			CustomerNotFoundException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException,
			AccountBlockedException, SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean fundTransfer(int customerIdTo, int accountNoTo,
			int customerIdFrom, int accountNoFrom, float transferAmount,
			int pinNumber) throws InsufficientAmountException,
			CustomerNotFoundException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException,
			AccountBlockedException, SQLException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Customer getCustomerDetails(int customerId)
			throws CustomerNotFoundException, BankingServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Account getAccountDetails(int customerId, int accountNo)
			throws CustomerNotFoundException, AccountNotFoundException,
			BankingServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int generateNewPin(int customerId, int accountNo)
			throws CustomerNotFoundException, AccountNotFoundException,
			BankingServicesDownException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean changeAccountPin(int customerId, int accountNo,
			int oldPinNumber, int newPinNumber)
			throws CustomerNotFoundException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Customer> getAllCustomerDetails()
			throws BankingServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Account> getcustomerAllAccountDetails(int customerId)
			throws BankingServicesDownException, CustomerNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Transaction> getAccountAllTransaction(int customerId,
			int accountNo) throws BankingServicesDownException,
			CustomerNotFoundException, AccountNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String accountStatus(int customerId, int accountNo)
			throws BankingServicesDownException, CustomerNotFoundException,
			AccountNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void close() throws BankingServicesDownException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int acceptCustomerDetails(Customer customer)
			throws BankingServicesDownException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean deleteCustomer(int customerID)
			throws BankingServicesDownException, ClassNotFoundException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean authenticateCustomer(Customer customer)
			throws CustomerNotFoundException, BankingServicesDownException {
		// TODO Auto-generated method stub
		return false;
	}
	
}
