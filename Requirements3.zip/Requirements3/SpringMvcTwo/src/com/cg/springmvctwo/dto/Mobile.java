package com.cg.springmvctwo.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="mobiledata")
public class Mobile 
{
	private Integer mobileId;
	private String mobileName;
	private String mobileBrand;
	private Double mobilePrice;
	
	//Getters and setters:
	@Id
	@Column(name="mob_id")
	public Integer getMobileId() 
	{
		return mobileId;
	}
	public void setMobileId(Integer mobileId) 
	{
		this.mobileId = mobileId;
	}
	
	@Column(name="mob_name")
	public String getMobileName() 
	{
		return mobileName;
	}
	public void setMobileName(String mobileName)
	{
		this.mobileName = mobileName;
	}
	
	@Column(name="mob_brand")
	public String getMobileBrand() 
	{
		return mobileBrand;
	}
	public void setMobileBrand(String mobileBrand) 
	{
		this.mobileBrand = mobileBrand;
	}
	
	@Column(name="mob_price")
	public Double getMobilePrice() 
	{
		return mobilePrice;
	}
	public void setMobilePrice(Double mobilePrice) 
	{
		this.mobilePrice = mobilePrice;
	}
	
	//To string:
	@Override
	public String toString() 
	{
		return "Mobile [mobileId=" + mobileId + ", mobileName=" + mobileName
				+ ", mobileBrand=" + mobileBrand + ", mobilePrice="
				+ mobilePrice + "]";
	}
}