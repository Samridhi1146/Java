package com.cg.payroll.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.payroll.beans.Employee;
import com.cg.payroll.exceptions.EmployeeDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

@Controller
public class EmployeeController
{
	@Autowired
	PayrollServices service;
	
	//Adding employee:
	@RequestMapping(value="add" , method=RequestMethod.GET)
	public String addData(@ModelAttribute("my") Employee emp, Map<String,Object> model)
	{
		return "first";
	}
	
	@RequestMapping(value="putData", method=RequestMethod.POST)
	public String dataAdd(@ModelAttribute("my") Employee emp) throws EmployeeDetailsNotFoundException, PayrollServicesDownException, SQLException 
	{
		service.acceptEmployeeDetails(emp);
		return "index";
	}
	
	//Searching an employee:
	@RequestMapping(value="search",method=RequestMethod.GET)
	public String searchData(@ModelAttribute ("mysearch") Employee emp)
	{
		return "search";
	}
	
	@RequestMapping(value="searchEmployee", method=RequestMethod.GET)
	public ModelAndView searchTrainee(@ModelAttribute("mysearch") Employee emp) throws EmployeeDetailsNotFoundException, PayrollServicesDownException, SQLException
	{
		int empId = emp.getEmpId();
		Employee mySearch = service.getEmployeeDetails(empId);
		return new ModelAndView("show", "emp", mySearch);
	}
	
	//Show all employees:
	@RequestMapping(value="showAll", method=RequestMethod.GET)
	public ModelAndView showData() throws PayrollServicesDownException, SQLException
	{
		List<Employee> dataList=service.getAllEmployeeDetails();
		return new ModelAndView("showAll", "employee", dataList);
	}
	
	//Deleting an employee:
	@RequestMapping(value="delete", method=RequestMethod.GET)
	public String removeData(@RequestParam("id")Integer id) throws SQLException
	{
		System.out.println(id);
		service.removeEmployee(id);
		return "index";
	}
	
	//Update an employee:
	@RequestMapping(value="update", method=RequestMethod.GET)
	public String updateEmployee(@RequestParam("id")Integer id, Map<String,Object> model, @ModelAttribute("data")Employee employee) throws EmployeeDetailsNotFoundException, PayrollServicesDownException, SQLException
	{
		employee = service.getEmployeeDetails(id);
		model.put("data", employee);
		
		return "updateemployee";
	}
	
	@RequestMapping(value ="/updateData" , method = RequestMethod.POST)
	public String updateData(@ModelAttribute("data")Employee emp) throws SQLException, EmployeeDetailsNotFoundException, PayrollServicesDownException
	{
		service.updateEmployee(emp);
		return "index";
	}
	
	//PDF Generation:
	@RequestMapping(value ="/generatepdf" , method = RequestMethod.POST)
	public String generate(@ModelAttribute("data")Employee emp,HttpServletRequest request,
            HttpServletResponse response) throws SQLException, EmployeeDetailsNotFoundException, PayrollServicesDownException
	{
		Document document = new Document();
		
	      try
	      {
	         PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("PaySlip.pdf"));
	         document.open();
	         
	         PdfPTable table = new PdfPTable(18);
	         PdfPCell c1=null;
	         
		        c1 = new PdfPCell(new Phrase("Employee ID"));
		        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		        table.addCell(c1);
		        
		        c1 = new PdfPCell(new Phrase("First Name"));
		        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		        table.addCell(c1);

		        c1 = new PdfPCell(new Phrase("Last Name	"));
		        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		        table.addCell(c1);
		        
		        c1 = new PdfPCell(new Phrase("Mobile No"));
		        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		        table.addCell(c1);
		        
		        c1 = new PdfPCell(new Phrase("Pan Card No"));
		        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		        table.addCell(c1);
		        
		        c1 = new PdfPCell(new Phrase("Email Id"));
		        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		        table.addCell(c1);
		        
		        c1 = new PdfPCell(new Phrase("Bank Name"));
		        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		        table.addCell(c1);
		        
		        c1 = new PdfPCell(new Phrase("BankIFSCCode"));
		        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		        table.addCell(c1);
		        
		        c1 = new PdfPCell(new Phrase("AccountNo"));
		        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		        table.addCell(c1);
		        
		        c1 = new PdfPCell(new Phrase("BasicSalary"));
		        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		        table.addCell(c1);
		        
		        c1 = new PdfPCell(new Phrase("Hra"));
		        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		        table.addCell(c1);
		        
		        c1 = new PdfPCell(new Phrase("TA"));
		        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		        table.addCell(c1);
		        
		        c1 = new PdfPCell(new Phrase("DA"));
		        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		        table.addCell(c1);
		        
		        c1 = new PdfPCell(new Phrase("COMPANYPF"));
		        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		        table.addCell(c1);
		        
		        c1 = new PdfPCell(new Phrase("EMPLOYEEPF"));
		        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		        table.addCell(c1);
		        
		        c1 = new PdfPCell(new Phrase("GROSSSALARY"));
		        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		        table.addCell(c1);
		        
		        c1 = new PdfPCell(new Phrase("MONTHLYTAX"));
		        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		        table.addCell(c1);
		        
		        c1 = new PdfPCell(new Phrase("NETSALARY"));
		        c1.setHorizontalAlignment(Element.ALIGN_CENTER);
		        table.addCell(c1);
		        
		        table.setHeaderRows(1);

		        table.addCell(Integer.toString(emp.getEmpId()));
		        table.addCell(emp.getFirstName());
		        table.addCell(emp.getLastName());
		        table.addCell(emp.getMobile());
		        table.addCell(emp.getPan());
		        table.addCell(emp.getEmail());
		        table.addCell(emp.bankDetails.getBankName());
		        table.addCell(emp.bankDetails.getBankIFSCCode());
		        table.addCell(Integer.toString(emp.bankDetails.getAccountNo()));
		        table.addCell(Double.toString(emp.salary.getBasicSalary()));
		        table.addCell(Double.toString(emp.salary.getHra()));
		        table.addCell(Double.toString(emp.salary.getTa()));
		        table.addCell(Double.toString(emp.salary.getDa()));
		        table.addCell(Double.toString(emp.salary.getCompanyPf()));
		        table.addCell(Double.toString(emp.salary.getEmployeePf()));
		        table.addCell(Double.toString(emp.salary.getGrossSalary()));
		        table.addCell(Double.toString(emp.salary.getMonthlyTax()));
		        table.addCell(Double.toString(emp.salary.getNetSalary()));
		     document.add(table);
	         document.close();
	         writer.close();
	      }
	      catch (DocumentException e)
	      {
	         e.printStackTrace();
	      }
	      catch (FileNotFoundException e)
	      {
	         e.printStackTrace();
	      }
	      
		return "index";
		/*
		String pdfName= emp.getEmpId()+" "+emp.getFirstName()+" "+emp.getLastName()+".pdf";
		System.out.print("Inside  genratePdf " + emp);
		File pdfFoler =new File("d:\\EmployeePayroll.PDf");
		if(!pdfFoler.exists())
		pdfFoler.mkdir();
		File pdffFile= new File(pdfFoler.getAbsolutePath()+"\\"+pdfName);  
		try {
		FileInputStream response1=new FileInputStream(pdfName);
		ServletOutputStream out=response.getOutputStream();
		response.setContentType("application/pdf");
		out.writer();
		} catch (IOException e) {
		e.printStackTrace();
		}
		return "index";
		*/
	}
}