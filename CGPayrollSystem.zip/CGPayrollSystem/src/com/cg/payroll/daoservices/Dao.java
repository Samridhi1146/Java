package com.cg.payroll.daoservices;

import java.sql.SQLException;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;
import com.cg.payroll.beans.Employee;
import org.hibernate.Session;

@Repository("dao")
public class Dao implements PayrollDAOServices
{
	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public void insertEmployee(Employee employee) throws SQLException 
	{
		entityManager.persist(employee);
		entityManager.flush();
	}

	@Override
	public Employee getEmployee(int employeeId) throws SQLException 
	{
		Employee employee=entityManager.find(Employee.class, employeeId);
		
		/*Query querytwo = entityManager.createQuery("FROM Employee WHERE employeeId=:employee_id");
		querytwo.setParameter("employee_id", employeeId);
		Employee searchEmployee = (Employee) querytwo.getSingleResult();*/
	
		return employee;
	}
	
	@Override
	public void updateEmployee(Employee employee) throws SQLException 
	{
		entityManager.merge(employee);
		
		/*Query queryFour = entityManager.createQuery("Update Employee Set firstName=:firstName,lastName=:lastName,mobile=:mobile,pan=:pan,email=:email,bankDetails.bankName=:bankName,bankDetails.accountNo=:accountNo,bankDetails.bankIFSCCode=:bankIFSCCode,salary.basicSalary=:basicSalary where empId=:empId");
		queryFour.setParameter("firstName", employee.getFirstName());
		queryFour.setParameter("lastName", employee.getLastName());
		queryFour.setParameter("mobile", employee.getMobile());
		queryFour.setParameter("pan", employee.getPan());
		queryFour.setParameter("email", employee.getEmail());
		queryFour.setParameter("bankName", employee.getBankDetails().getBankName());
		queryFour.setParameter("accountNo", employee.getBankDetails().getAccountNo());
		queryFour.setParameter("bankIFSCCode", employee.getBankDetails().getBankIFSCCode());
		queryFour.setParameter("basicSalary", employee.getSalary().getBasicSalary());
		queryFour.setParameter("empId", employee.getEmpId());
		queryFour.executeUpdate();*/
	}

	@Override
	public void deleteEmployee(int employeeId) throws SQLException 
	{
		Query queryThree = entityManager.createQuery("DELETE FROM Employee WHERE empId=:employee_id");
		queryThree.setParameter("employee_id", employeeId);
		queryThree.executeUpdate();
	}

	@Override
	public List<Employee> getAllEmployees() throws SQLException 
	{
		Query queryOne = entityManager.createQuery("FROM Employee");
		List<Employee> allData = queryOne.getResultList();
		return allData;
	}
}