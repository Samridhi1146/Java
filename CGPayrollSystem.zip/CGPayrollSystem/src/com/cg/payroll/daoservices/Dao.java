package com.cg.payroll.daoservices;

import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.payroll.beans.Employee;

@Repository("dao")
public class Dao implements PayrollDAOServices
{

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public void insertEmployee(Employee employee) throws SQLException {
		entityManager.persist(employee);
		entityManager.flush();
	}

	@Override
	public Employee getEmployee(int employeeId) throws SQLException {
		Query querytwo = entityManager.createQuery("FROM Employee WHERE employeeId=:employee_id");
		querytwo.setParameter("employee_id", employeeId);
		Employee searchEmployee = (Employee) querytwo.getSingleResult();
	
		return searchEmployee;
	}
	
	@Override
	public boolean updateEmployee(Employee employee) throws SQLException {
		Query queryFour = entityManager.createQuery("Update Employee Set FIRSTNAME=:employee_fname,LASTNAME=:employee_lname,MOBILE=:employee_mobile,PAN=:employee_pcard,");
		queryFour.setParameter("employee_fname", employee.getFirstName());
		queryFour.setParameter("employee_lname", employee.getLastName());
		queryFour.setParameter("employee_mobile", employee.getMobile());
		queryFour.setParameter("employee_pcard", employee.getPan());
		queryFour.setParameter("employee_pcard", employee.getEmail());
		queryFour.setParameter("employee_pcard", employee.getBankDetails());
		queryFour.setParameter("employee_pcard", employee.getSalary());
		queryFour.executeUpdate();
		return false;
	}

	@Override
	public void deleteEmployee(int employeeId) throws SQLException {

		Query queryThree = entityManager.createQuery("DELETE FROM Employee WHERE employeeId=:employee_id");
		queryThree.setParameter("employee_id", employeeId);
		queryThree.executeUpdate();
	}

	@Override
	public List<Employee> getAllEmployees() throws SQLException {
		Query qureyOne = entityManager.createQuery("FROM Employee");
		List<Employee> allData = qureyOne.getResultList();
		
		return allData;
	}

}
