package com.cg.payroll.exceptions;

public class EmployeeDetailsNotFoundException extends Exception 
{
	public EmployeeDetailsNotFoundException() 
	{
		super();
	}

	public EmployeeDetailsNotFoundException(String message, Throwable cause,boolean enableSuppression, boolean writableStackTrace) 
	{
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public EmployeeDetailsNotFoundException(String message, Throwable cause) 
	{
		super(message, cause);
	}

	public EmployeeDetailsNotFoundException(String message) 
	{
		super(message);
	}

	public EmployeeDetailsNotFoundException(Throwable cause) 
	{
		super(cause);
	}
}