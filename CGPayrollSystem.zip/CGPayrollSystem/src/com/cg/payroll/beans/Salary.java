package com.cg.payroll.beans;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class Salary
{
	@Column(name="BASICSALARY")
	private double basicSalary;
	
	@Column(name="HRA")
	private double hra;
	
	@Column(name="TA")
	private double ta;
	
	@Column(name="DA")
	private double da;
	
	@Column(name="COMPANYPF")
	private double companyPf=3840;
	
	@Column(name="EMPLOYEEPF")
	private double employeePf=3840;
	
	@Column(name="GROSSSALARY")
	private double grossSalary;
	
	@Column(name="MONTHLYTAX")
	private double monthlyTax;
	
	@Column(name="NETSALARY")
	private double netSalary;
	
	//Getters and setters:
	public double getBasicSalary() 
	{
		return basicSalary;
	}
	public void setBasicSalary(double basicSalary) 
	{
		this.basicSalary = basicSalary;
	}
	public double getHra() 
	{
		return hra;
	}
	public void setHra(double hra) 
	{
		this.hra = hra;
	}
	public double getTa() 
	{
		return ta;
	}
	public void setTa(double ta) 
	{
		this.ta = ta;
	}
	public double getDa() 
	{
		return da;
	}
	public void setDa(double da) 
	{
		this.da = da;
	}
	public double getCompanyPf() 
	{
		return companyPf;
	}
	public void setCompanyPf(double companyPf) 
	{
		this.companyPf = 3840;;
	}
	public double getEmployeePf() 
	{
		return employeePf;
	}
	public void setEmployeePf(double employeePf) 
	{
		this.employeePf = 3840;
	}
	public double getGrossSalary() 
	{
		return grossSalary;
	}
	public void setGrossSalary(double grossSalary) 
	{
		this.grossSalary = grossSalary;
	}
	public double getMonthlyTax() 
	{
		return monthlyTax;
	}
	public void setMonthlyTax(double monthlyTax) 
	{
		this.monthlyTax = monthlyTax;
	}
	public double getNetSalary() 
	{
		return netSalary;
	}
	public void setNetSalary(double netSalary) 
	{
		this.netSalary = netSalary;
	}
	
	//To string:
	@Override
	public String toString() 
	{
		return "Salary [basicSalary=" + basicSalary + ", hra=" + hra + ", ta="
				+ ta + ", da=" + da + ", companyPf=" + companyPf
				+ ", employeePf=" + employeePf + ", grossSalary=" + grossSalary
				+ ", monthlyTax=" + monthlyTax + ", netSalary=" + netSalary
				+ "]";
	}
}