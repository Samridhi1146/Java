package com.cg.payroll.beans;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="EMPLOYEEMASTER")
public class Employee
{
	@Id
	@Column(name="EMPLOYEEID")
	/*@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="employeeid")
	 *@SequenceGenerator(name="employeeid",sequenceName=" EMPLOYEEID_SEQ")*/

	@GeneratedValue(strategy=GenerationType.TABLE)
	private int empId;
	
	@Column(name="FIRSTNAME")
	private String firstName;
	
	@Column(name="LASTNAME")
	private String lastName;
	
	@Column(name="MOBILE")
	private String mobile;
	
	@Column(name="PAN")
	private String pan;
	
	@Column(name="EMAIL")
	private String email;
	
	@Column(name="YEARLYINVESTMENT")
	private int yearlyInvestment;

	@Embedded
	private BankDetails bankDetails;
	
	@Embedded
	private Salary salary;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getPan() {
		return pan;
	}
	public void setPan(String pAN) {
		pan = pAN;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getYearlyInvestment() {
		return yearlyInvestment;
	}
	public void setYearlyInvestment(int yearlyInvestment) {
		this.yearlyInvestment = yearlyInvestment;
	}
	public BankDetails getBankDetails() {
		return bankDetails;
	}
	public void setBankDetails(BankDetails bankDetails) {
		this.bankDetails = bankDetails;
	}
	public Salary getSalary() {
		return salary;
	}
	public void setSalary(Salary salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", mobile=" + mobile + ", pan="
				+ pan + ", email=" + email + ", yearlyInvestment="
				+ yearlyInvestment + ", bankDetails=" + bankDetails
				+ ", salary=" + salary + "]";
	}
	
	
}