package com.cg.springdemotwo.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.cg.springdemotwo.services.Employee;

public class MyMain 
{
	public static void main(String[] args) 
	{
		ApplicationContext app=new ClassPathXmlApplicationContext("spring.xml");		
		Employee employeeData=(Employee)app.getBean("emp");
		employeeData.showEmployee();
	}
}