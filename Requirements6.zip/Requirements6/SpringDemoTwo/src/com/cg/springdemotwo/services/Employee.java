package com.cg.springdemotwo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.cg.springdemotwo.dto.Department;

@Component("emp")
public class Employee 
{
	@Autowired
	Department dept;
	
	public Department getDept() {
		return dept;
	}

	public void setDept(Department dept) {
		this.dept = dept;
	}
	@Value("ABCD")
	String empName;
	
	public void showEmployee()
	{
		System.out.println("Springs using annotation.");
		System.out.println("Name is: "+empName);
		dept.showDepartment();
	}

	//Getters and setters.
	public String getEmpName() 
	{
		return empName;
	}
	public void setEmpName(String empName) 
	{
		this.empName = empName;
	}	
}