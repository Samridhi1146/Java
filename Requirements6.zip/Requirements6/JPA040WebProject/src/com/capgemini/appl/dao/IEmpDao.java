package com.capgemini.appl.dao;

import java.util.List;

import com.capgemini.appl.entities.Dept;
import com.capgemini.appl.entities.Emp;
import com.capgemini.appl.exceptions.CustomException;

public interface IEmpDao 
{
	public void addNewEmp(Emp emp) throws CustomException;
	
	Emp getEmpDetails(int empNo)throws CustomException;
	
	Dept getDeptDetails(int deptNo) throws CustomException;
}