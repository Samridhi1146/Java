package com.capgemini.appl.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.capgemini.appl.entities.Dept;
import com.capgemini.appl.entities.Emp;
import com.capgemini.appl.exceptions.CustomException;
import com.capgemini.appl.util.JpaUtil;

public class EmpDaoImpl implements IEmpDao
{
	//Instance variable:
	//EntityManagerFactory factory=null;
	//Reference:
	private EntityManager manager;
	
	public EmpDaoImpl()
	{
		//Call super first in constructor.
		super();
		//Factory created,gives entity manager and creates pool of connections.
		//EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-SK");
		manager=JpaUtil.getEntityManager();
	}
	
	@Override
	public void addNewEmp(Emp emp) throws CustomException
	{
		EntityTransaction trans=manager.getTransaction();
		trans.begin();
		
		manager.persist(emp);
		
		trans.commit();
	}
	
	public Emp getEmpDetails(int empNo)
	{
		Emp emp=manager.find(Emp.class,empNo);
		return emp;
	}
	
		public void closeFactory()
		{
			//factory.close();
			JpaUtil.close();
		}
		
		@Override
		protected void finalize() throws Throwable 
		{
			JpaUtil.close();
			//closeFactory();
			//Call super here in exact opposite order of constructor:
			super.finalize();
		}

		@Override
		public Dept getDeptDetails(int deptNo) throws CustomException 
		{
			Dept dept=(Dept)manager.find(Dept.class,deptNo);
			return dept;
		}
}