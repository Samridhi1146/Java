package com.capgemini.appl.services;

import java.util.List;

import com.capgemini.appl.entities.Dept;
import com.capgemini.appl.entities.Emp;
import com.capgemini.appl.exceptions.CustomException;

public interface IEmpServices 
{
	public void addNewEmp(Emp emp) throws CustomException;
	
	Emp getEmpDetails(int empNo) throws CustomException;
	
	public Dept getDeptDetails(int deptNo) throws CustomException;
}